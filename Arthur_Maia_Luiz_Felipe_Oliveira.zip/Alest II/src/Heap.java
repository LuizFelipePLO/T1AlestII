//Arthur Maia e Luiz Felipe PUCRS Alest II

import java.util.ArrayList;
import java.util.Comparator;
import java.util.NoSuchElementException;

public class Heap{
		
		ArrayList<Nodes> items;
		ArrayList<Nodes> balanced;
		
		
		//create the arrayList
		public Heap() {
			items = new ArrayList<Nodes>();
			balanced = new ArrayList<Nodes>();
		}
		
		
		 //method that goes over the arrayList and checks if the node is balanced 
		@SuppressWarnings("unused")
		public void siftUp() {
			int k = items.size() - 1;
			int left = 0;
			int right = 0;
			int i=0;
			int y=0;
			Nodes parent = null;
			while (k >= 0) {
				
					if(k != 0) {
						right = items.get(k).getValor();
						left = items.get(k-1).getValor();
						
						parent = items.get((k-1)/2);
						parent.setValue(left+right);
						
						}
					
					if(k == 0) {
						right = items.get(k+1).getValor();
						left = items.get(k+2).getValor();
					}
					if (left-right == 0) {
							balanced.add(parent);
							items.get(k).setBoolean();
							i++;
						}
						k--;
						k--;
						
				} 
			System.out.println("O numero de nodos balanceados � de:" + i+ ", e s�o eles: \n");
		}
			
		public void show() {
			balanced = SortedNodes(balanced);
			for(int i=0;i<balanced.size();i++) {
				System.out.println(balanced.get(i)+" com o valor de: " + balanced.get(i).getValor());
			}
			System.out.println();
		}
		
		//method that show the total number of nodes (balanced and unbalanced)
		public void showTodos() {
			
			int y=0;
			int i=0;
			
				for(Nodes n:items) {
					if(n.getBalanced() == true) {i++;}
					else {y++;}
					
					
				}
				System.out.println(y);
				System.out.println(i);
		}
		
		//insert a new node
		public void insert(Nodes item) {
			items.add(item);
		}
		
		//setters and getters
		public int size() {
			return items.size();
		}
		
		public boolean isEmpty() {
			return items.isEmpty();
			
		}
		
		public String toString() {
			return items.toString();
		}
		
		//comparator
		private static ArrayList<Nodes> SortedNodes(ArrayList<Nodes> preBalanced)
		    {
		        preBalanced.sort(new Comparator<Nodes>() {
		            @Override
		            public int compare(Nodes a1, Nodes a2) {
		                return a1.getNome().compareTo(a2.getNome());
		            }
		        });
		        return preBalanced;
		    }
}