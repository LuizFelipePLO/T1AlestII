//Arthur Maia e Luiz Felipe PUCRS Alest II

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class App {

	
	public static void main(String[] args) {
	
		
		//get the files (couldnt make a relative path)
		ArrayList<String>lines5 = getFileLines("C:\\Users\\Arthur Maia\\Documents\\teste5.txt");
		ArrayList<String>lines6 = getFileLines("C:\\Users\\Arthur Maia\\Documents\\teste6.txt");
		ArrayList<String>lines7 = getFileLines("C:\\Users\\Arthur Maia\\Documents\\teste7.txt");
		ArrayList<String>lines8 = getFileLines("C:\\Users\\Arthur Maia\\Documents\\teste8.txt");
		ArrayList<String>lines9 = getFileLines("C:\\Users\\Arthur Maia\\Documents\\teste9.txt");
		ArrayList<String>lines10 = getFileLines("C:\\Users\\Arthur Maia\\Documents\\teste10.txt");
		ArrayList<String>lines11 = getFileLines("C:\\Users\\Arthur Maia\\Documents\\teste11.txt");
		ArrayList<String>lines12 = getFileLines("C:\\Users\\Arthur Maia\\Documents\\teste12.txt");
		ArrayList<String>lines13 = getFileLines("C:\\Users\\Arthur Maia\\Documents\\teste13.txt");
		
		//method that transforms the file into the nodes
		parse(lines5);
		parse(lines6);
		parse(lines7);
		parse(lines8);
		parse(lines9);
		parse(lines10);
		parse(lines11);
		parse(lines12);
		parse(lines13);
		
	}

	//read the files and transforms it into a arraylist
	private static ArrayList<String> getFileLines(String path)
    {
        ArrayList<String> lines = new ArrayList<String>();
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(path));
            String line = reader.readLine();
            while (line != null) {
                lines.add(line);
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lines;
    }

	//read the arraylist and transform it into nodes
	private static void parse(ArrayList<String> lines) {
		
		Heap hp = new Heap();
		
		ArrayList<String> node = lines;
		
		//first line of the file is all new nodes
		String line0 = lines.get(0); 
		String[] split0 = line0.split(" ");
		hp.insert(new Nodes(split0[0]));
		hp.insert(new Nodes(split0[1]));
		hp.insert(new Nodes(split0[2]));
		
		//after the first line the first node has already been added to the program
		for (int i = 1; i < lines.size(); i++)
		{	
			String line = node.get(i);
			
			String[] split = line.split(" ");
			
			//taking the first node of the line 
			split = Arrays.copyOfRange(split, 1, 3);
			
			
			// inserting the new node 
			hp.insert(new Nodes(split[0]));
			hp.insert(new Nodes(split[1]));
		}
		
		//method that goes over the arrayList and checks if the node is balanced
		hp.siftUp();
		
		//(method that shows all nodes ->)hp.showTodos();
		
		//show all balanced nodes
		hp.show();
		
	}
}