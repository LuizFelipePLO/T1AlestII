//Arthur Maia e Luiz Felipe PUCRS Alest II

public class Nodes{

	private String nome = "";
	private int valor = 0;
	private boolean balanced = false;
	
	//constructor
	public Nodes(String nome){
		this.nome = nome;
		
		//puts the name of the node as its value if its possible
		try {
			int x = Integer.parseInt(nome);
					setValue(x);
			} catch (Exception e) {
				//e.printStackTrace();
			}
	}
	
	//setters and getter
	public void setValue(int valor) {
		this.valor = valor;
	}
	
	public void setBoolean() {
		this.balanced = true;
	}
	
	public int getValor() {
		return this.valor;
	}
	
	public boolean getBalanced() {
		return this.balanced;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public String toString() {
		return this.nome;
	}
	
}
